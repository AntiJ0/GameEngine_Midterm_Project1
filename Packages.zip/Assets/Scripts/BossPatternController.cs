using UnityEngine;
using System.Collections;

public class BossPatternController : MonoBehaviour
{
    public float patternDuration = 10f;

    public SpikeSpawner spikeSpawner;
    public FallingObjectSpawner fallingSpawner;
    public ProjectileSpawner projectileSpawner;

    public void StartAllPatterns()
    {
        Debug.Log("StartAllPatterns() 호출됨");
        StartCoroutine(PatternLoop());
    }

    private IEnumerator PatternLoop()
    {
        while (true)
        {
            Debug.Log("보스 패턴 코루틴 시작됨");

            // 1. 가시 패턴
            Debug.Log("가시 패턴 시작 전");
            if (spikeSpawner != null)
                spikeSpawner.StartPattern(patternDuration);
            yield return new WaitForSeconds(patternDuration);
            Debug.Log("가시 패턴 시작 완료");

            // 2. 낙하 패턴
            Debug.Log("낙하 패턴 시작 전");
            if (fallingSpawner != null)
                fallingSpawner.StartPattern(patternDuration);
            yield return new WaitForSeconds(patternDuration);
            Debug.Log("낙하 패턴 시작 완료");

            // 3. 투사체 패턴
            Debug.Log("투사체 패턴 시작 전");
            if (projectileSpawner != null)
                projectileSpawner.StartPattern(patternDuration);
            yield return new WaitForSeconds(patternDuration);
            Debug.Log("투사체 패턴 시작 완료");
        }
    }
}