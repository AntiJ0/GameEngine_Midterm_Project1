using UnityEngine;

public class FakeGoalTrigger : MonoBehaviour
{
    private bool triggered = false;

    [Header("강화 아이템 활성화 관련")]
    public GameObject attackItemToActivate;

    [Header("패턴 스포너 오브젝트")]
    public GameObject spikeSpawnerObject;
    public GameObject fallingSpawnerObject;
    public GameObject projectileSpawnerObject;

    [Header("보스 패턴 컨트롤러")]
    public BossPatternController bossPatternController;

    [Header("보스 패턴 시작 딜레이")]
    public float initialPatternDelay = 5f;

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (triggered || !other.CompareTag("Player")) return;

        triggered = true;
        Debug.Log("FakeGoal 트리거 발동됨!");

        // 공격 아이템 활성화
        if (attackItemToActivate != null)
        {
            attackItemToActivate.SetActive(true);
        }

        // 일정 시간 후 보스 패턴 시작
        Invoke(nameof(StartBossPattern), initialPatternDelay);
    }

    private void StartBossPattern()
    {
        Debug.Log("보스 패턴 시작함!");

        if (bossPatternController != null)
        {
            bossPatternController.StartAllPatterns(); // ← 인자 없는 버전
        }
        else
        {
            Debug.LogError("BossPatternController가 연결되지 않았습니다!");
        }
    }
}