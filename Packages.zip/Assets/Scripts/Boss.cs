using UnityEngine;
using UnityEngine.SceneManagement;

public class Boss : MonoBehaviour
{
    public int maxHp = 10;
    private int currentHp;

    private void Start()
    {
        currentHp = maxHp;
    }

    public void TakeDamage(int amount)
    {
        currentHp -= amount;

        if (currentHp <= 0)
        {
            Die();
        }
    }

    private void Die()
    {
        Debug.Log("보스 사망!");
        // 보스 제거 (원하는 연출 넣기)
        Destroy(gameObject);

        // 보스전 종료 처리 → 예시로 씬 이동
        SceneManager.LoadScene("StageClear"); // 원하면 다른 씬 이름으로 수정
    }
}