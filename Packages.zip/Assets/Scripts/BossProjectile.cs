using UnityEngine;

public class BossProjectile : MonoBehaviour
{
    public float speed = 5f;
    public float lifeTime = 5f;

    private Rigidbody2D rb;

    private void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        if (rb == null)
        {
            Debug.LogError("❌ Rigidbody2D가 없습니다!");
            return;
        }

        rb.velocity = -transform.up * speed;
        Debug.Log("📌 현재 velocity: " + rb.velocity);  // ← 여기에 출력

        Destroy(gameObject, lifeTime);
    }
}