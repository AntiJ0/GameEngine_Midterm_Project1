using UnityEngine;
using UnityEngine.Tilemaps;

public class TilemapActivator : MonoBehaviour
{
    public Tilemap tilemapToActivate;

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            tilemapToActivate.GetComponent<TilemapRenderer>().enabled = true;
            tilemapToActivate.GetComponent<TilemapCollider2D>().enabled = true;

            Destroy(gameObject);
        }
    }
}
